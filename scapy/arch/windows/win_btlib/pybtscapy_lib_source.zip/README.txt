This file is part of Scapy
See http://www.secdev.org/projects/scapy for more informations
Copyright (C) Gabriel POTTER
This program is published under a GPLv2 license

The following project is a Microsoft Visual Studio project, which contains scapy's bluetooth driver.
To use it properly, please update in the project's properties tab:
- C/C++ > General: Additional Include Directories
- Linker > General: Additional Library Directories

The project needs the default libraries + python symbols (lookup on google how to install them), located in 
the directory: C:/Python27/Symbols, to work properly

It's aiming at supporting both x86 and x64 versions of Windows (2 different architectures in the arch tab)
For more informations, please refer to the github repo https://github.com/secdev/scapy